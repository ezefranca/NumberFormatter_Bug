import Foundation


extension String {
    func toDouble() -> Double? {
        return NumberFormatter().number(from: self)?.doubleValue
    }
}

let badString = " -9.3456"
let goodString = "-9.3456"

assert(badString.toDouble() == goodString.toDouble(), "bad conversion")

print(badString.toDouble())
print(goodString.toDouble())

// On a real device, the badString.toDouble() returns nil

